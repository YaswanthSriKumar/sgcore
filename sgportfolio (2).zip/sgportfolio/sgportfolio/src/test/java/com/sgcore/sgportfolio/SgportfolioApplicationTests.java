package com.sgcore.sgportfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgportfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
