import React, { useState, useEffect } from 'react';
import { AppBar, Toolbar, IconButton, Box, Button, Drawer, List, ListItem, ListItemText, useMediaQuery } from '@mui/material';
import { Link } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import DarkModeIcon from '@mui/icons-material/DarkMode'; // Import Dark Mode Icon
import './nav.css';

const Nav = ({ toggleDarkMode, isDarkMode }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  console.log("is it dark mood in nav :   "+isDarkMode);

  const isMobile = useMediaQuery('(max-width:1200px)');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  return (
    <>
      <AppBar position="fixed" className={`${isScrolled ? 'BaseColours' : 'navbarnav'} ${isDarkMode ? 'dark-mode-navbar' : ''}`}>
        <Toolbar sx={{ justifyContent: 'space-between', padding: '0 !important', width: '90%', left: '5%', borderBottom: '2px solid white' }}>
          <Box sx={{ width: '30%' }}>
            <h2>My Website</h2>
          </Box>

          {!isMobile && (
            < >
              <Button color="inherit"  component={Link} to="/home">Home</Button>
              <Button color="inherit" component={Link} to="/about">Services</Button>
              <Button color="inherit" component={Link} to="/services">Products</Button>
              <Button color="inherit" component={Link} to="/contact">Portfolio</Button>
              <Button color="inherit" component={Link} to="/contact">Careers</Button>
              <Button color="inherit" component={Link} to="/contact">AboutUs</Button>
              <Button color="inherit" component={Link} to="/contact">ContactUs</Button>
            </>
          )}

          {/* Dark Mode Toggle Button */}
          <IconButton color="inherit" onClick={toggleDarkMode}>
            <DarkModeIcon />
          </IconButton>

          {isMobile && (
            <IconButton color="inherit" aria-label="open drawer" edge="end" onClick={handleDrawerToggle} className="hamburger-icon">
              <MenuIcon />
            </IconButton>
          )}
        </Toolbar>
      </AppBar>

      <Drawer anchor="right" open={mobileOpen} onClose={handleDrawerToggle} className="drawer" classes={{ paper: 'drawer-paper' }}>
        <List>
          <ListItem component={Link} to="/home" onClick={handleDrawerToggle}>
            <ListItemText primary="Home" />
          </ListItem>
          <ListItem component={Link} to="/about" onClick={handleDrawerToggle}>
            <ListItemText primary="About" />
          </ListItem>
          <ListItem component={Link} to="/services" onClick={handleDrawerToggle}>
            <ListItemText primary="Services" />
          </ListItem>
          <ListItem component={Link} to="/contact" onClick={handleDrawerToggle}>
            <ListItemText primary="Contact" />
          </ListItem>
        </List>
      </Drawer>
    </>
  );
};

export default Nav;
