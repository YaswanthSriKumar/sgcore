package com.sgcore.sgServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
