package com.sgcore.sgServices.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.sgcore.sgServices.Dto.ServiceDto;
import com.sgcore.sgServices.entity.ServicesEntity;
import com.sgcore.sgServices.repository.ServiceRepo;

@Service
public class AddService {

	@Autowired
	ServiceRepo serviceRepo ;
	

	
	public ResponseEntity<String> addService(String name,String description,boolean show,MultipartFile image ) throws IOException
	{	
			ServicesEntity servicesEntity = new ServicesEntity();
			servicesEntity.setServiceName(name);
			servicesEntity.setServiceDescription(description);
			servicesEntity.setServiceShow(show);
			if (image != null && !image.isEmpty()) {
	            byte[] imageBytes = image.getBytes(); // Read file as bytes
	            servicesEntity.setServiceImage(imageBytes);
	        } else {
	            return ResponseEntity.badRequest().body("Image path is missing or invalid");
	        }
			Optional<ServicesEntity> result =Optional.of(serviceRepo.save(servicesEntity)) ;
			 if(result.isPresent())
		            return ResponseEntity.status(HttpStatus.CREATED).body("service uploaded successfully");
				else
		            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload service");
	
	}

	public ResponseEntity<List<ServiceDto>> getServices() {
		Optional<List<ServicesEntity>>  result =Optional.of(serviceRepo.findAll()) ;
		if(result.isPresent())
		{
			 // Convert entities to DTOs with image URLs
		    List<ServiceDto> resultDto = result.get().stream().map(service -> {
		    	ServiceDto dto = new ServiceDto();
		        dto.setServiceId(service.getServiceId());
		        dto.setServiceName(service.getServiceName());
		        dto.setServiceDescription(service.getServiceDescription());
		        dto.setServiceShow(service.isServiceShow());
		       
		        dto.setServiceImage("http://localhost:8088/SGSERVICES/image/" + service.getServiceId()); // Construct image URL
		        return dto;
		    }).toList();
		    return ResponseEntity.status(HttpStatus.OK).body(resultDto);
		}
           
	
		else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	public ResponseEntity<byte[]> findById(int id) {
		Optional<ServicesEntity> service = serviceRepo.findById(id);
		
		if(service.isPresent())
		{
			System.out.println("sending ");
			 return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG) // Adjust to IMAGE_PNG or other type if needed
	                .body(service.get().getServiceImage());
		}
		else
		{
			System.out.println("notsending");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(service.get().getServiceImage());
		}
		
		// TODO Auto-generated method stub
//		Optional<ServicesEntity> service =Optional.of(serviceRepo.findById(id));
//	
//
//        return ResponseEntity.ok()
//                .contentType(MediaType.IMAGE_JPEG) // Adjust to IMAGE_PNG or other type if needed
//                .body(service.getServiceImage());
//		return serviceRepo.findById(id);
	}

	public ResponseEntity<List<ServiceDto>> getSelectedServices() {
		Optional<List<ServicesEntity>>  result =Optional.of(serviceRepo.findByServiceShow(true)) ;
		if(result.isPresent())
		{
			 // Convert entities to DTOs with image URLs
		    List<ServiceDto> servicesDtos = result.get().stream().map(service -> {
		    	ServiceDto dto = new ServiceDto();
		        dto.setServiceId(service.getServiceId());
		        dto.setServiceName(service.getServiceName());
		        dto.setServiceDescription(service.getServiceDescription());
		        dto.setServiceShow(service.isServiceShow());
		       
		        dto.setServiceImage("http://localhost:8088/SGSERVICES/image/" + service.getServiceId()); // Construct image URL
		        System.out.println( dto.getServiceImage());
		        return dto;
		    }).toList();
		    return ResponseEntity.status(HttpStatus.CREATED).body(servicesDtos);
		}
           
	
		else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	public ResponseEntity<String> updateShow(int id, ServiceDto servicesDto) {
		Optional<ServicesEntity> result =serviceRepo.findById(id) ;
		if(result.isPresent())
		{
			result.get().setServiceShow(servicesDto.isServiceShow());
			Optional<ServicesEntity>  serviceEntity =Optional.of(serviceRepo.save(result.get()) );
			if (serviceEntity.isPresent())
			{
				 return ResponseEntity.status(HttpStatus.OK).body("update successfull");
			}
			else
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("update fail");
				
			
		}
		
		 return ResponseEntity.status(HttpStatus.NOT_FOUND).body("record not found");
	}
	public ResponseEntity<String> updateService(int id,String name,String description,boolean show,MultipartFile image ) throws IOException
	{	Optional<ServicesEntity> present=serviceRepo.findById(id);
		
	if(present.isPresent())
	{		System.out.println("yes is present");

		ServicesEntity servicesEntity = new ServicesEntity();
		servicesEntity.setServiceId(id);
		servicesEntity.setServiceName(name);
		servicesEntity.setServiceDescription(description);
		servicesEntity.setServiceShow(show);
		if (image != null && !image.isEmpty()) {
            byte[] imageBytes = image.getBytes(); // Read file as bytes
            servicesEntity.setServiceImage(imageBytes);
        } else {
            return ResponseEntity.badRequest().body("Image path is missing or invalid");
        }
		Optional<ServicesEntity> result =Optional.of(serviceRepo.save(servicesEntity)) ;
		 if(result.isPresent())
	            return ResponseEntity.status(HttpStatus.CREATED).body("service uploaded successfully");
			else
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload service");
	}
	else
	{
		System.out.println("no not present");
	}
			
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("service not found");
	}
	
}
