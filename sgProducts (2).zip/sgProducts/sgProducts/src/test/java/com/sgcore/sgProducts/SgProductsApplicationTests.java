package com.sgcore.sgProducts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
